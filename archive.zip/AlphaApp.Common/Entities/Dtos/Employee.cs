﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlphaApp.Common.Entities.Dtos
{
    public class Employee
    {
        public bool Status { get; set; }
        public int country_id { get; set; }
        public string name { get; set; }
    }
}
